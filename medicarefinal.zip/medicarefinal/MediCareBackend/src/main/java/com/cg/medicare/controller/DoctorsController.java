package com.cg.medicare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.medicare.dto.Doctors;
import com.cg.medicare.service.DoctorsService;

@RestController
@RequestMapping("/doctorsdetails")
@CrossOrigin("http://localhost:4200")
public class DoctorsController {
	@Autowired
	DoctorsService doctorsService;
	
	@PostMapping("/adddoctor")
	public Doctors addDoctors(@RequestBody Doctors doctor) {
		return doctorsService.addDoctors(doctor);
	}
	
	@GetMapping("/showalldoctors")
	public List<Doctors> showAllDoctors(){
		return doctorsService.showAllDoctors();
	}
	
	@GetMapping("/getdoctorbydisease/{disease}")
	public List<Doctors> getDoctorsByDisease(@PathVariable("disease") String diseases){
		return doctorsService.getDoctorByDisease(diseases);
	}
	                                                                                                                                                                                                                                                               
   @DeleteMapping("/deletedoctor/{mobileno}")
    public void deleteDoctor(@PathVariable("mobileno") Long mobile) {
	   System.out.println("mobile to delte is"+mobile);
	 doctorsService.deleteDoctor(mobile);
     }
   
   @PutMapping("/updatedoctors/{mobileno}/{timing}/{location}")
   public Doctors updateDoctor(@PathVariable("mobileno") Long mobile,@PathVariable("timing") String time,@PathVariable("location") String location) {
	   System.out.println("in controller"+mobile+time+location);
	   return doctorsService.updateDoctor(mobile, time, location);
   }

   @GetMapping("/getdoctorbymobile/{mobileno}/")
   public Doctors getDoctorByMobile(@PathVariable("mobileno") Long mobile) {
   return doctorsService.findDoctor(mobile);
   }
}
