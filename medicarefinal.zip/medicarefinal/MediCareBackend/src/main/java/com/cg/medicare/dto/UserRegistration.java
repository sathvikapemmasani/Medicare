package com.cg.medicare.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "users_register")
public class UserRegistration {
	@Id
	@Indexed(name="_id")
	private Long mobileNo;
	private String userName;
	private String gender;
	private String email;
	private String password;
	private String role;
	private String securityquestion;
	private String answer;
	private List<String> docemail;
	private List<String> medicineId;
	private String status;
	
	public List<String> getMedicineId() {
		return medicineId;
	}
	public void setMedicineId(List<String> medicineId) {
		this.medicineId = medicineId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<String> getDocemail() {
		return docemail;
	}
	public void setDocemail(List<String> docemail) {
		this.docemail = docemail;
	}
	private Integer totalprice=0;
	public Integer getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(Integer totalprice) {
		this.totalprice = totalprice;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getSecurityquestion() {
		return securityquestion;
	}
	public void setSecurityquestion(String securityquestion) {
		this.securityquestion = securityquestion;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
	
	
	public UserRegistration(Long mobileNo, String userName, String gender, String email, String password, String role,
			String securityquestion, String answer, List<String> docemail, List<String> medicineId, String status,
			Integer totalprice) {
		super();
		this.mobileNo = mobileNo;
		this.userName = userName;
		this.gender = gender;
		this.email = email;
		this.password = password;
		this.role = role;
		this.securityquestion = securityquestion;
		this.answer = answer;
		this.docemail = docemail;
		this.medicineId = medicineId;
		this.status = status;
		this.totalprice = totalprice;
	}
	public UserRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "UserRegistration [mobileNo=" + mobileNo + ", userName=" + userName + ", gender=" + gender + ", email="
				+ email + ", password=" + password + ", role=" + role + ", securityquestion=" + securityquestion
				+ ", answer=" + answer + ", docemail=" + docemail + ", medicineId=" + medicineId + ", status=" + status
				+ ", totalprice=" + totalprice + "]";
	}
	
	
	
	
}
