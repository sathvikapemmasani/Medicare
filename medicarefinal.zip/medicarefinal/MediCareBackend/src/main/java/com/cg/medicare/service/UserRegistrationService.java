package com.cg.medicare.service;

import java.util.List;

import com.cg.medicare.dto.Doctors;
import com.cg.medicare.dto.Medicines;
import com.cg.medicare.dto.UserRegistration;

public interface UserRegistrationService {
	public boolean validateMobileandAnswer(Long mobileno, String answer);
	public boolean validateUserLogin(Long mobile, String password); 
	public UserRegistration addNewUser(UserRegistration user);
	public void updatepassword(Long mobile, String pwd);
	public List<UserRegistration> getAllUserDeatils();
	public void deleteUser(Long mobileNo);
	public String getAdminAndUserDetails(Long mobile, String password);
	public String getRole(Long mobile);
	public Integer booking(Long mobileNo, String dmail) ;
	public List<UserRegistration> getDetails(String dmail);
	public Integer cancelBooking(Long cmobile,String docmail);
	public List<Doctors> doctorsList(Long cmobile);
	public String getstatus(Long cmobile);
	public Integer addMedicinesList(Long cmobile,String medicineId);
	public List<Medicines> getMedicinesList(Long cmobile);
	public Integer setstatus(Long cmobile, Long dmobile);
	public Integer getstatus(Long cmobile, Long dmobile);

}
