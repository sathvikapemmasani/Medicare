package com.cg.medicare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medicare.dao.UserRegistrationDao;
import com.cg.medicare.dto.Doctors;
import com.cg.medicare.dto.Medicines;
import com.cg.medicare.dto.UserRegistration;

@Service
public class UserRegistrationServiceImpl implements UserRegistrationService{
	@Autowired
	UserRegistrationDao userRegistrationDao;

	@Override
	public boolean validateMobileandAnswer(Long mobileno, String answer) {
		// TODO Auto-generated method stub
		return userRegistrationDao.validateMobileandAnswer(mobileno, answer);
	}

	@Override
	public boolean validateUserLogin(Long mobile, String password) {
		// TODO Auto-generated method stub
		return userRegistrationDao.validateUserLogin(mobile, password);
	}

	@Override
	public UserRegistration addNewUser(UserRegistration user) {
		// TODO Auto-generated method stub
		return userRegistrationDao.addNewUser(user);
	}

	@Override
	public void updatepassword(Long mobile, String pwd) {
		// TODO Auto-generated method stub
		userRegistrationDao.updatepassword(mobile, pwd);
		
	}

	@Override
	public List<UserRegistration> getAllUserDeatils() {
		// TODO Auto-generated method stub
		return userRegistrationDao.getAllUserDeatils();
	}

	@Override
	public void deleteUser(Long mobileNo) {
		// TODO Auto-generated method stub
		userRegistrationDao.deleteUser(mobileNo);
		
	}

	@Override
	public String getAdminAndUserDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getAdminAndUserDetails(mobile, password);
	}

	@Override
	public String getRole(Long mobile) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getRole(mobile);
	}

	@Override
	public Integer booking(Long mobileNo, String dmail) {
		// TODO Auto-generated method stub
		return userRegistrationDao.booking(mobileNo, dmail);
	}

	@Override
	public List<UserRegistration> getDetails(String dmail) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getDetails(dmail);
	}

	@Override
	public Integer cancelBooking(Long cmobile, String docmail) {
		// TODO Auto-generated method stub
		return userRegistrationDao.cancelBooking(cmobile, docmail);
	}

	@Override
	public List<Doctors> doctorsList(Long cmobile) {
		// TODO Auto-generated method stub
		return userRegistrationDao.doctorsList(cmobile);
	}


	@Override
	public String getstatus(Long cmobile) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getstatus(cmobile);
	}

	@Override
	public Integer addMedicinesList(Long cmobile, String medicineId) {
		// TODO Auto-generated method stub
		return userRegistrationDao.addMedicinesList(cmobile, medicineId);
	}

	@Override
	public List<Medicines> getMedicinesList(Long cmobile) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getMedicinesList(cmobile);
	}

	@Override
	public Integer setstatus(Long cmobile, Long dmobile) {
		// TODO Auto-generated method stub
		return userRegistrationDao.setstatus(cmobile,dmobile);
	}

	@Override
	public Integer getstatus(Long cmobile, Long dmobile) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getstatus(cmobile,dmobile);
	}

}
