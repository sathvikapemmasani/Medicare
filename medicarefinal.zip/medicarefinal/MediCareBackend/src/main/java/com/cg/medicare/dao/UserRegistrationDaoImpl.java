package com.cg.medicare.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.medicare.dto.Doctors;
import com.cg.medicare.dto.Medicines;
import com.cg.medicare.dto.UserRegistration;

@Repository
public class UserRegistrationDaoImpl implements UserRegistrationDao{

	int first=1;
	@Autowired
	MongoTemplate mongotemplate;
Doctors d;
Medicines m;

	@Override
	public boolean validateMobileandAnswer(Long mobileno, String answer) {
		// TODO Auto-generated method stub
		boolean flag=false;
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobileno)) {
				if(details.getAnswer().equalsIgnoreCase(answer)) {
					System.out.println("in dao"+mobileno+answer);
					flag=true;
				}
			}
		}
		return flag;
	}

	@Override
	public boolean validateUserLogin(Long mobile, String password) {
		boolean flag=false;
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobile)) {
				if(details.getPassword().equalsIgnoreCase(password)) {
					System.out.println("in dao password "+password);
					flag=true;
					return flag;
				}
			}
		}
		Doctors d=mongotemplate.findOne(Query.query(Criteria.where("doctorMobile").is(mobile)),Doctors.class );
		if(d.getPassword().equalsIgnoreCase(password)) {
			if(d.getRole()==null) {
				d.setRole("doctor");
				
				mongotemplate.save(d);
			}
			flag=true;
		}
			
		
		
		System.out.println("flag value"+flag);
		return flag;
	}

	@Override
	public UserRegistration addNewUser(UserRegistration user) {
		// TODO Auto-generated method stub
		
		return  mongotemplate.insert(user);
	}

	@Override
	public void updatepassword(Long mobile, String pwd) {
		// TODO Auto-generated method stub
		System.out.println("before password is"+pwd);
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobile)) {
				details.setPassword(pwd);
				mongotemplate.save(details);
				System.out.println("after password"+details.getPassword());
			}
		}
		
		
	}

	@Override
	public List<UserRegistration> getAllUserDeatils() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(UserRegistration.class);
	}

	@Override
	public void deleteUser(Long mobileNo) {
		// TODO Auto-generated method stub
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobileNo)) {
				mongotemplate.remove(details);
			}
		}
		
	}

	@Override
	public String getAdminAndUserDetails(Long mobile, String password) {
		// TODO Auto-generated method stub
		String roles="";
		List<UserRegistration>user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:user) {
			if(details.getMobileNo().equals(mobile)) {
				if(details.getPassword().equalsIgnoreCase(password)) {
					roles=details.getRole();
				}
			}
		}
		return roles;
	}

	@Override
	public String getRole(Long mobile) {
		// TODO Auto-generated method stub
		List<UserRegistration> user1=mongotemplate.findAll(UserRegistration.class);
		System.out.println("role is"+user1);
		for(UserRegistration user:user1 ) {
			if(user.getMobileNo().equals(mobile)) {
		System.out.println("user role is"+user.getRole());
		return user.getRole();
		
		}
		}
		Doctors d=mongotemplate.findOne(Query.query(Criteria.where("doctorMobile").is(mobile)),Doctors.class );
		System.out.println("doctor login"+d.getRole());
		if(d.getRole().equalsIgnoreCase("doctor"))
		{
			System.out.println("doctorv match");
			return d.getRole();
		}
		else
		return null;
	}


	
	
	@Override
	public Integer booking(Long mobileNo, String docemail) {
		// TODO Auto-generated method stub
		System.out.println("booking dao"+mobileNo+docemail);
		UserRegistration user=mongotemplate.findOne(Query.query(Criteria.where("mobileNo").is(mobileNo)),UserRegistration.class );
		List<String> array1=new ArrayList<>();
		System.out.println("user details in booking  :"+user);
		if(user.getDocemail()==null) {
		//array1=user.getDocemail();
		array1.add(docemail);
	    user.setDocemail(array1);
		}
		else
		{
			array1=user.getDocemail();
			array1.add(docemail);
		    user.setDocemail(array1);
		   
		}
		mongotemplate.save(user);
		

		return 1;
	}

	//method for  fetching all the booked customers for a particular technician
	@Override
	public List<UserRegistration> getDetails(String docmail) {
		// TODO Auto-generated method stub
		List<UserRegistration> user=getAllUserDeatils();
		List<UserRegistration> userdetails=new ArrayList<>();
		List<String> sample=new ArrayList<>();
		System.out.println("user details"+user);
		for(UserRegistration details:user) {
			System.out.println("testing "+details.getDocemail());
			 sample=details.getDocemail();
			 System.out.println("sample"+sample);
			 for(String mail:sample) {
				 System.out.println("mail idssss"+mail);
			if(mail!=null) {
			
				if(mail.equalsIgnoreCase(docmail)){

					userdetails.add(details);
					System.out.println("details in getdetails"+userdetails);
					
				}
			}
		}
			

		}
		return userdetails;
	}

	@Override
	public Integer cancelBooking(Long cmobile, String docmail) {
		UserRegistration user=mongotemplate.findOne(Query.query(Criteria.where("mobileNo").is(cmobile)),UserRegistration.class );
		
		List<String> mailList=user.getDocemail();
		System.out.println("In dao before mailList:"+mailList);

		mailList.remove(docmail);
		System.out.println("In dao after mailList:"+mailList);
		user.setDocemail(mailList);
		
		mongotemplate.save(user);
		// TODO Auto-generated method stub
		return 1;
		
	}

	@Override
	public List<Doctors> doctorsList(Long cmobile) {
		// TODO Auto-generated method stub
	UserRegistration user=mongotemplate.findOne(Query.query(Criteria.where("mobileNo").is(cmobile)),UserRegistration.class );
	List<String> sample=new ArrayList<>();
	List<Doctors> userdetails=new ArrayList<>();
	sample=user.getDocemail();
	for(String doc:sample) {
		
			System.out.println("doc mails"+doc);
			Doctors d=mongotemplate.findOne(Query.query(Criteria.where("email").is(doc)),Doctors.class );
			System.out.println("d record"+d);
			userdetails.add(d);
		System.out.println("in loop"+userdetails);
		
		
	}
	System.out.println("out loop"+userdetails);
		
		return userdetails;
	}

	@Override
	public Integer setstatus(Long cmobile,Long dmobile) {
		System.out.println("Inside status");
		List<Long> cmob=new ArrayList<>();
		Doctors doctors=mongotemplate.findOne(Query.query(Criteria.where("doctorMobile").is(dmobile)),Doctors.class );
		// TODO Auto-generated method stub
		System.out.print("outside if"+doctors);
			System.out.print("in dao"+doctors);
		cmob.add(cmobile);
		doctors.setcMobile(cmob);
		mongotemplate.save(doctors);
		
		return 1;
	}

	@Override
	public String getstatus(Long cmobile) {
		// TODO Auto-generated method stub
		UserRegistration user=mongotemplate.findOne(Query.query(Criteria.where("mobileNo").is(cmobile)),UserRegistration.class );
		
		return user.getStatus();
	}

	@Override
	public Integer addMedicinesList(Long cmobile, String medicineId) {
		// TODO Auto-generated method stub
		UserRegistration user=mongotemplate.findOne(Query.query(Criteria.where("mobileNo").is(cmobile)),UserRegistration.class );
		List<String> sample=new ArrayList<>();
		
		if(user.getMedicineId()==null) {
			//array1=user.getDocemail();
			sample.add(medicineId);
		    user.setMedicineId(sample);
			}
			else
			{
				sample=user.getMedicineId();
				sample.add(medicineId);
			    user.setMedicineId(sample);;
			   System.out.println("sample is"+sample);
			}
		
		
		
		mongotemplate.save(user);
		return 1;
	}

	@Override
	public List<Medicines> getMedicinesList(Long cmobile) {
		// TODO Auto-generated method stub
		UserRegistration user=mongotemplate.findOne(Query.query(Criteria.where("mobileNo").is(cmobile)),UserRegistration.class );
List<Medicines> md=new ArrayList<>();
List<String> sample=new ArrayList<>();
sample=user.getMedicineId();
for(String sample1:sample) {
m=mongotemplate.findOne(Query.query(Criteria.where("medicineId").is(sample1)),Medicines.class );
md.add(m);
}
		return md;
	}

	@Override
	public Integer getstatus(Long cmobile, Long dmobile) {
		// TODO Auto-generated method stub
		Doctors doctor=mongotemplate.findOne(Query.query(Criteria.where("doctorMobile").is(dmobile)),Doctors.class );
		if(doctor.getcMobile()!=null) {
		List<Long> cmob=doctor.getcMobile();
		
		for(Long mob:cmob) {
			if(mob.equals(cmobile))
				return 1;
		}
		}
		return 2;
	}
	
	
	

}
