package com.cg.medicare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.medicare.dao.DoctorsDao;
import com.cg.medicare.dto.Doctors;

@Service
public class DoctorsServiceImpl implements DoctorsService{
	@Autowired
	DoctorsDao doctorsDao;

	@Override
	public List<Doctors> showAllDoctors() {
		// TODO Auto-generated method stub
		return doctorsDao.showAllDoctors();
	}

	@Override
	public Doctors findDoctor(Long doctorMobile) {
		// TODO Auto-generated method stub
		return doctorsDao.findDoctor(doctorMobile);
	}

	@Override
	public Doctors addDoctors(Doctors doctor) {
		// TODO Auto-generated method stub
		return doctorsDao.addDoctors(doctor);
	}

	@Override
	public List<Doctors> getDoctorByDisease(String doctorDisease) {
		// TODO Auto-generated method stub
		return doctorsDao.getDoctorByDisease(doctorDisease);
	}

	@Override
	public void deleteDoctor(Long doctorMobile) {
		// TODO Auto-generated method stub
		doctorsDao.deleteDoctor(doctorMobile);
		
	}

	@Override
	public Doctors updateDoctor(Long doctorMobile, String doctorTiming, String doctorLocation) {
		// TODO Auto-generated method stub
		return doctorsDao.updateDoctor(doctorMobile, doctorTiming, doctorLocation);
	}

}
