package com.cg.medicare.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.medicare.dto.Medicines;
import com.cg.medicare.dto.UserRegistration;

@Repository
public class MedicineDaoImpl implements MedicineDao{
	@Autowired
	MongoTemplate mongoTemplate;
	Integer totalPrice=0;

	@Override
	public List<Medicines> showAllMedicines() {
		// TODO Auto-generated method stub
		
		return mongoTemplate.findAll(Medicines.class);
	}

	@Override
	public Medicines addMedicine(Medicines medicine) {
		// TODO Auto-generated method stub
		
		return mongoTemplate.insert(medicine);
	}

	@Override
	public List<Medicines> searchByMedicineName(String medicineName) {
		// TODO Auto-generated method stub
		List<Medicines> medicine=mongoTemplate.findAll(Medicines.class);
		List<Medicines> medicinedetails=new ArrayList<Medicines>();
		for(Medicines details:medicine) {
			if(details.getMedicineName().equalsIgnoreCase(medicineName)) {
				medicinedetails.add(details);
			
			}
		}
		return medicinedetails;
	}

	@Override
	public List<Medicines> searchByMedicineReason(String medicineReason) {
		// TODO Auto-generated method stub
		List<Medicines> medicine=mongoTemplate.findAll(Medicines.class);
		List<Medicines> medicinedetails=new ArrayList<>();
		for(Medicines details:medicine) {
			if(details.getMedicineReason().equalsIgnoreCase(medicineReason)) {
				medicinedetails.add(details);
				System.out.println("list of medicines"+medicinedetails);
				
				
			}
		}
		return medicinedetails;
	}

	@Override
	public void deleteMedicine(String medicineId) {
		// TODO Auto-generated method stub
		List<Medicines> medicines=mongoTemplate.findAll(Medicines.class);
		for(Medicines details:medicines) {
			if(details.getMedicineId().equals(medicineId)) {
				mongoTemplate.remove(details);
			}
		}
		
		
	}

	@Override
	public Medicines updateMedicine(String medicineId, String medicinePrice) {
		// TODO Auto-generated method stub
		List<Medicines> medicines=mongoTemplate.findAll(Medicines.class);
		for(Medicines details:medicines) {
			if(details.getMedicineId().equals(medicineId)) {
				details.setMedicinePrice(medicinePrice);
				mongoTemplate.save(details);
				return details;
			}
		
	}
	
return null;
	}

	@Override
	public Integer getPrice(Long customermobile, String price) {
		List<UserRegistration> details=mongoTemplate.findAll(UserRegistration.class);
		System.out.println("data "+details);
		
		for(UserRegistration data:details) {
			System.out.println("in for");
			System.out.println("dao mobile"+data.getMobileNo());
			System.out.println("indao mobile paramenter"+customermobile);
			if(data.getMobileNo().equals(customermobile)) {
				System.out.println("in if"+data.getMobileNo());
				//data.setTotalPrice(price);
				System.out.println("in if"+data.getTotalprice());
				Integer cost=Integer.parseInt(price);
				totalPrice=data.getTotalprice()+cost;
				data.setTotalprice(totalPrice);
				mongoTemplate.save(data);
				return totalPrice;
	}
		}
		return totalPrice;
	}

	@Override
	public void setprice(Long customermobile) {
		// TODO Auto-generated method stub
				List<UserRegistration> details=mongoTemplate.findAll(UserRegistration.class);
				for(UserRegistration data:details) {
					System.out.println("in for");
					if(data.getMobileNo().equals(customermobile)) {
						System.out.println("in if"+data.getMobileNo());
						//data.setTotalPrice(price);
					
						
						data.setTotalprice(0);
						mongoTemplate.save(data);
				
			}
				}
			
}
}
