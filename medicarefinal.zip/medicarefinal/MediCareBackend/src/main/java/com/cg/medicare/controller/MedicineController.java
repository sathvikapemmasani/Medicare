package com.cg.medicare.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.medicare.dto.Medicines;
import com.cg.medicare.service.MedicineService;

@RestController
@RequestMapping("/medicine")
@CrossOrigin("http://localhost:4200")
public class MedicineController {
	@Autowired
	MedicineService medicineService;
	
	 
	
	@PostMapping("/addMedicines")
	public void saveMedicines(@RequestParam("file") MultipartFile file1) throws IOException{
	System.out.println("oy");
	String line,name="C:\\Users\\sapemmas\\"+file1.getOriginalFilename();

	FileReader fr=new FileReader(name);
	   BufferedReader br=new BufferedReader(fr);
	   Medicines medicine1=new Medicines();
	while((line=br.readLine())!=null) {
	Medicines medicine=new Medicines();
	String[] data=line.split(",");
	medicine.setMedicineId(data[0]);
	medicine.setMedicineName(data[1]);
	for (String string : data) {
	System.out.println(string);
	}
	medicine.setMedicineUsage(data[2]);
	medicine.setMedicineReason(data[3]);
	medicine.setMedicineValidity(data[4]);
	medicine.setMedicinePrice(data[5]);
	medicine.setImage(data[6]);

	medicineService.addMedicine(medicine);
	}
	}

	
	@GetMapping("/getAllMedicine")
	public List<Medicines> getAllMedicines(){
		return medicineService.showAllMedicines();
	}
	
	@GetMapping("/getMedicineByName/{medicinename}")
	public List<Medicines> getMedicineByName(@PathVariable("medicinename") String name) {
		return medicineService.searchByMedicineName(name);
	}
	
	@GetMapping("/getMedicineByReason/{medicineReason}")
	public List<Medicines> getMedicineByReason(@PathVariable("medicineReason") String reason) {
		return medicineService.searchByMedicineReason(reason);
	}
	
	@PutMapping("/updatemedicine/{medicineId}/{price}")
	public Medicines updateMedicinePrice(@PathVariable("medicineId") String id,@PathVariable("price") String price) {
		return medicineService.updateMedicine(id, price);
	}
	
	@DeleteMapping("/deleteMedicine/{medicineId}")
	public void DeleteMedicine(@PathVariable("medicineId") String id) {
		medicineService.deleteMedicine(id);
	}
	
	@GetMapping("/getprice/{customermobile}/{price}")
	public Integer getPrice(@PathVariable("customermobile") Long cmobile,@PathVariable("price") String price) {
		System.out.println("in get price controller"+cmobile+price);
		return medicineService.getPrice(cmobile, price);
	}
	@GetMapping("/setprice/{customermobile}")
		public void setprice(@PathVariable("customermobile") Long cmobile) {
		medicineService.setprice(cmobile);
		}

}
