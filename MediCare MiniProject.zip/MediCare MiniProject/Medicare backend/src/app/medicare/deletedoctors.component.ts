import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-deletedoctors',
  templateUrl: './deletedoctors.component.html',
  styleUrls: ['./deletedoctors.component.css']
})
export class DeletedoctorsComponent implements OnInit {
  result:any=[];
  data:any=[];

  constructor(private service:MedicareserviceService) { }
  deleteDoctor(mobileNo:any)
  {
    console.log("in delete doctor ts file"+mobileNo);
    let index=this.data.indexOf(mobileNo);
    this.data.splice(index,1);
     window.location.reload(); 
      this.service.deleteDoctor(mobileNo).subscribe();

  }

  ngOnInit() {
    this.service.getAllDoctors().subscribe(result=>{this.data=result;
    });

  }

}
