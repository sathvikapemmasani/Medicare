import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {

  constructor(private router:Router) { }
  adddoctorsbutton(){
this.router.navigate(['/adddoctors'])
}
addmedicinesbutton(){
this.router.navigate(['/addmedicines'])
}

viewdoctorsbutton(){
this.router.navigate(['/viewdoctors'])
}
viewmedicinesbutton(){
this.router.navigate(['/viewmedicines'])
}
  ngOnInit() {
  }

}
