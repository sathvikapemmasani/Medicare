import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-customerviewmedicines',
  templateUrl: './customerviewmedicines.component.html',
  styleUrls: ['./customerviewmedicines.component.css']
})
export class CustomerviewmedicinesComponent implements OnInit {
data:any=[];
mobile:any;
totalprice:any;
message:boolean=false;
  constructor(private service:MedicareserviceService) { }

  addToCart(price:any){

    this.message=true;
    this.mobile=localStorage.getItem("mobile")
    this.service.getPrice(this.mobile,price).subscribe(data=>{this.totalprice=data
    console.log("data of price is"+this.totalprice)});
    

  }

  ngOnInit() {
    this.service.getAllMedicines().subscribe(result=>{this.data=result;
    })
   
  }

}
