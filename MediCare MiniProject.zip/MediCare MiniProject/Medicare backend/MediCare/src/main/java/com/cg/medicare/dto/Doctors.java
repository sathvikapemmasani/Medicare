package com.cg.medicare.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "doctors_details")
public class Doctors {
	@Id
	@Indexed(name="_id")
	private Long doctorMobile;
	private String doctorName;
	private String doctorSpecalization;
	private String availableTiming;
	private String doctorLocation;
	private String doctorDisease;
	private String password;
	private String email;
	private String role;
	private List<Long> cMobile;
	
	
	
	public List<Long> getcMobile() {
		return cMobile;
	}
	public void setcMobile(List<Long> cMobile) {
		this.cMobile = cMobile;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getDoctorMobile() {
		return doctorMobile;
	}
	public void setDoctorMobile(Long doctorMobile) {
		this.doctorMobile = doctorMobile;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDoctorSpecalization() {
		return doctorSpecalization;
	}
	public void setDoctorSpecalization(String doctorSpecalization) {
		this.doctorSpecalization = doctorSpecalization;
	}
	public String getAvailableTiming() {
		return availableTiming;
	}
	public void setAvailableTiming(String availableTiming) {
		this.availableTiming = availableTiming;
	}
	public String getDoctorLocation() {
		return doctorLocation;
	}
	public void setDoctorLocation(String doctorLocation) {
		this.doctorLocation = doctorLocation;
	}
	
	
	public String getDoctorDisease() {
		return doctorDisease;
	}
	public void setDoctorDisease(String doctorDisease) {
		this.doctorDisease = doctorDisease;
	}
	public Doctors(Long doctorMobile, String doctorName, String doctorSpecalization, String availableTiming,
			String doctorLocation, String doctorDisease, String password, String email, String role,
			List<Long> cMobile) {
		super();
		this.doctorMobile = doctorMobile;
		this.doctorName = doctorName;
		this.doctorSpecalization = doctorSpecalization;
		this.availableTiming = availableTiming;
		this.doctorLocation = doctorLocation;
		this.doctorDisease = doctorDisease;
		this.password = password;
		this.email = email;
		this.role = role;
		this.cMobile = cMobile;
	}
	@Override
	public String toString() {
		return "Doctors [doctorMobile=" + doctorMobile + ", doctorName=" + doctorName + ", doctorSpecalization="
				+ doctorSpecalization + ", availableTiming=" + availableTiming + ", doctorLocation=" + doctorLocation
				+ ", doctorDisease=" + doctorDisease + ", password=" + password + ", email=" + email + ", role=" + role
				+ ", cMobile=" + cMobile + "]";
	}
	public Doctors() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
		
}
