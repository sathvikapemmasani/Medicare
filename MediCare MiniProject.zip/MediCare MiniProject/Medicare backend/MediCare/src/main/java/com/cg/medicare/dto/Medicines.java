package com.cg.medicare.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "medicines_data")
public class Medicines {
	@Id
	@Indexed(name="_id")
	private String medicineId;
	private String medicineName;
	private String medicineUsage;
	private String medicineReason;
	private String medicineValidity;
	private String medicinePrice;
	private String image;
	
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getMedicineId() {
		return medicineId;
	}
	public void setMedicineId(String medicineId) {
		this.medicineId = medicineId;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public String getMedicineUsage() {
		return medicineUsage;
	}
	public void setMedicineUsage(String medicineUsage) {
		this.medicineUsage = medicineUsage;
	}
	public String getMedicineReason() {
		return medicineReason;
	}
	public void setMedicineReason(String medicineReason) {
		this.medicineReason = medicineReason;
	}
	public String getMedicineValidity() {
		return medicineValidity;
	}
	public void setMedicineValidity(String medicineValidity) {
		this.medicineValidity = medicineValidity;
	}
	public String getMedicinePrice() {
		return medicinePrice;
	}
	public void setMedicinePrice(String medicinePrice) {
		this.medicinePrice = medicinePrice;
	}
	
	public Medicines() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Medicines(String medicineId, String medicineName, String medicineUsage, String medicineReason,
			String medicineValidity, String medicinePrice, String image) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.medicineUsage = medicineUsage;
		this.medicineReason = medicineReason;
		this.medicineValidity = medicineValidity;
		this.medicinePrice = medicinePrice;
		this.image = image;
	}
	@Override
	public String toString() {
		return "Medicines [medicineId=" + medicineId + ", medicineName=" + medicineName + ", medicineUsage="
				+ medicineUsage + ", medicineReason=" + medicineReason + ", medicineValidity=" + medicineValidity
				+ ", medicinePrice=" + medicinePrice + ", image=" + image + "]";
	}
	
	
	

}
