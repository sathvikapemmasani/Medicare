import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-canceldoctor',
  templateUrl: './canceldoctor.component.html',
  styleUrls: ['./canceldoctor.component.css']
})
export class CanceldoctorComponent implements OnInit {
  mob:any;
  mobile:any;
  data:any=[];
  result:boolean=false;
  status1:any;
  status2:String;
  constructor(private service:MedicareserviceService) { }

  ngOnInit() {
    this.mob=localStorage.getItem("mobile");
    this.service.getDoctorsList(this.mob).subscribe(result=>this.data=result);
  }
  cancel(docemail){
    console.log("in cancel ts"+docemail);
    console.log("mobile"+this.mob);
    this.service.cancelDoctor(this.mob,docemail).subscribe();
    window.location.reload();

  }
  status(dmobile:number){
    this.result=true;
    this.mobile=localStorage.getItem("mobile");
    console.log("cmobile"+this.mobile);
    this.service.getStatus(this.mobile,dmobile).subscribe(data1=>{this.status1=data1
    console.log("status"+data1);  
    if(this.status1==1){
      this.status2="accepted";
    }
    else{
      this.status2="pending"; 
    }
  });

}
}
