import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customerviewdoctors',
  templateUrl: './customerviewdoctors.component.html',
  styleUrls: ['./customerviewdoctors.component.css']
})
export class CustomerviewdoctorsComponent implements OnInit {
data:any=[];
cmob:any;
booked:boolean=false;
show:boolean=false;
doctorName:String;
disableButton = false;
  constructor(private service:MedicareserviceService,private router:Router) { }
bookDoctor(email){
  this.booked=true;
  this.cmob=localStorage.getItem("mobile");
  this.service.addBooking(this.cmob,email).subscribe();
alert("booked successfully");
console.log("event"+event);
this.disableButton = true;
}

cancelDoctor(email){

}

next(){
  this.router.navigate(['/canceldoctor'])
}


  ngOnInit() {
    this.service.getAllDoctors().subscribe(result=>{this.data=result;
    })
   
  }

  onSearch(value){
    console.log(value);
   
    this.data=this.data.filter(b=>b.doctorName.toLowerCase().match(value.toLowerCase()) || b.doctorDisease.toLowerCase().match(value.toLowerCase()));
 
  }
  
  }


