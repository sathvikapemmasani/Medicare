import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  mobile:any;
  result:any;
  message:String;
  role:any;
  mob:any;
  show:boolean=false;
  constructor(private service:MedicareserviceService,private router:Router) { }
  check(mobile:any,password:String,email:any){
    
    console.log("login"+mobile+password);
      this.service.userlogin(mobile,password).subscribe((data:number)=>{this.result=data;
      console.log("loooo"+data);
      console.log("in service result"+this.result);
      if(this.result==true){
        this.service.getRole(mobile).subscribe(data1=>{this.role=data1;
       console.log("role"+this.role);
            if(this.role==1)
        {
        this.router.navigate(['/manager']);
        }
        else if(this.role==2){
          console.log("customer mobile"+mobile);
          this.mob=this.mobile;
          localStorage.setItem("mobile",this.mob);
          this.router.navigate(['/customer']);

        }
        else if(this.role==3){
          localStorage.setItem("dmobile",mobile);
          localStorage.setItem("docemail",email);
          console.log("doctor page")
        this.router.navigate(['/doctor'])
        }
    
      });
     
    }
    else{

      this.show=true;
      console.log("in ts"+this.show)
    

      /* this.router.navigate(['/logout'])  */
    }
   
    });
  
  }

  ngOnInit() {
  }

}
