import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  model1:any={}; 
  constructor(private service:MedicareserviceService,private router:Router) { }

  ngOnInit() {
  }

  updatePassword(mobile:number,pwd:string):any{
    console.log(mobile)
    this.service.changePassword(mobile,pwd).subscribe();
    this.router.navigate(['/userlogin']);
    
  }


}
