import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-updatedoctors',
  templateUrl: './updatedoctors.component.html',
  styleUrls: ['./updatedoctors.component.css']
})
export class UpdatedoctorsComponent implements OnInit {

  constructor(private service:MedicareserviceService) { }
  model:any={};
  id:number;
  timming:any;
  mobile:number;
  location:any;
  show:boolean=false;
  /* method for updating tests */
    updateDoctors(){
    console.log("in ts file"+this.id)
    this.show=true;
      
    this.service.updateDoctors(this.mobile,this.timming,this.location).subscribe();
    
  }
    ngOnInit() {
      this.mobile=this.service.currentDoctorMobile;
    }
  
}
