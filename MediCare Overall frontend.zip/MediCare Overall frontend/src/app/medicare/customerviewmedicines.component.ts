import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-customerviewmedicines',
  templateUrl: './customerviewmedicines.component.html',
  styleUrls: ['./customerviewmedicines.component.css']
})
export class CustomerviewmedicinesComponent implements OnInit {
data:any=[];
mobile:any;
totalprice:any;
message:boolean=false;
  constructor(private service:MedicareserviceService) { }

  addToCart(price:any,id:any){

    this.message=true;
    this.mobile=localStorage.getItem("mobile")
    this.service.getPrice(this.mobile,price).subscribe(data=>{this.totalprice=data
    console.log("data of price is"+this.totalprice)});
    this.service.setMedicinesList(this.mobile,id).subscribe();

  }

  ngOnInit() {
    this.service.getAllMedicines().subscribe(result=>{this.data=result;
    })
   
  }
  onSearch(value){
    console.log(value);
    this.data=this.data.filter(b=>b.medicineName.toLowerCase().match(value.toLowerCase()) || b.medicineReason.toLowerCase().match(value.toLowerCase()));
    
  }

}
