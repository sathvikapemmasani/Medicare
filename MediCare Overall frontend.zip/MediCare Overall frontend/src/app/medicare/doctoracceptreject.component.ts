import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doctoracceptreject',
  templateUrl: './doctoracceptreject.component.html',
  styleUrls: ['./doctoracceptreject.component.css']
})
export class DoctoracceptrejectComponent implements OnInit {

  result1:any=[];
  flag:boolean=false;
  data:any=[];
  val1:any=[];
  mob:number;
  docmail:any;
  userName: string;
  acceptmessage:boolean=false;
  rejectmessage:boolean=false;
  messaging:boolean=false;
  message:any;
  status:any;
  dmobile:any;
  constructor(private service:MedicareserviceService,private router:Router) { }
/* method for accepting booking */
acceptBooking(){
  console.log("in technician")
  
  
}
/*  method for accepting booking*/
accept(mobile){
  this.message=true;
  
  
  this.dmobile=localStorage.getItem("dmobile");
   this.userName="true";
  localStorage.setItem("acceptedmobile", mobile);
 this.acceptmessage=true; 
this.messaging=true;

  //localStorage.setItem("email", email)
 alert("Accepted"); 
 this.service.setStatus(mobile,this.dmobile).subscribe();
}
/* method for rejecting the booking */
reject(mobile){
  
  
   this.userName="false";
   localStorage.setItem("result", this.userName)
   this.messaging=true;
 this.rejectmessage=true;
 //localStorage.setItem("email", email)

 alert("Rejected"); 

}
Logout(){
  this.router.navigate(['/home'])
}


  ngOnInit() {
    this.docmail=localStorage.getItem("docemail");
console.log("in accept reject");
    return this.service.getBookedUsers(this.docmail).subscribe((result1:any)=>{
      this.val1=result1;
    })
    } 
  }


