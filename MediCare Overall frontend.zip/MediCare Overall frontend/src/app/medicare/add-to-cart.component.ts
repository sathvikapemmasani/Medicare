import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit {

  constructor(private service:MedicareserviceService) { }
data:any=[];
  ngOnInit() {

    this.service.getMedicinesList(localStorage.getItem("mobile")).subscribe(result=>this.data=result);
  }

}
