import { Component, OnInit } from '@angular/core';
import { MedicareserviceService } from '../medicareservice.service';

@Component({
  selector: 'app-addmedicines',
  templateUrl: './addmedicines.component.html',
  styleUrls: ['./addmedicines.component.css']
})
export class AddmedicinesComponent implements OnInit {
model:any={}
result:boolean=false;
  constructor(private service:MedicareserviceService) { }
  addMedicines(){
    this.result=true;
this.service.addmedicines(this.model).subscribe();
  }
  ngOnInit() {
  }

}
