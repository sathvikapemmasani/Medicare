import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MedicareserviceService {
  currentTestId:number=0;
  currentDoctorMobile:number=0;
  constructor(private http:HttpClient) { }

  
  addUserRegister(data:any){
    console.log("service"+data)
    let userinput={"mobileNo":data.mobile,
    "userName":data.username,
     "gender":data.gender,
    "role":data.role,
   "password":data.password,
   "email":data.email,
  "securityquestion":data.securityQuestion,
"answer":data.answer}
   console.log(data.mobile);
   console.log("service"+data.role);
    return this.http.post("http://localhost:9989/userregistration/addnewuser",userinput);
  }

  userlogin(mobile,password){
    return this.http.get("http://localhost:9989/userregistration/validate/"+mobile+"/"+password)
  }

  getRole(mobile){
    console.log("in medi service")
    return this.http.get("http://localhost:9989/userregistration/getuserrole/"+mobile);
  }

  //regarding doctors
  adddoctors(data:any){
    console.log("data added is"+data)
   let input={
      "doctorMobile":data.mobile,
	"doctorName":data.name,
	"doctorSpecalization":data.specilization,
	"availableTiming":data.timmings,
	"doctorLocation":data.location,
  "doctorDisease":data.disease,
  "password":data.password,
  "email":data.email

    }
    return this.http.post("http://localhost:9989/doctorsdetails/adddoctor",input)
  }

  addmedicines(data:any){
    console.log("data medicines is"+data)
    let input={
      "medicineId": data.id,
    "medicineName": data.name,
    "medicineUsage": data.usage,
    "medicineReason": data.reason,
    "medicineValidity": data.validity,
    "medicinePrice": data.price

    }
    return this.http.post("http://localhost:9989/medicine/addMedicine",input)
  }
  getAllDoctors()
  {
    return this.http.get("http://localhost:9989/doctorsdetails/showalldoctors")
  }
  deleteDoctor(mobileNo:any)
  {
    console.log("doctor mobile is"+mobileNo)
    return this.http.delete("http://localhost:9989/doctorsdetails/deletedoctor/"+mobileNo)
  }
  getAllMedicines()
  {
    return this.http.get("http://localhost:9989/medicine/getAllMedicine")
  }
  deleteMedicines(medicineId:any)
  {
    return this.http.delete("http://localhost:9989/medicine/deleteMedicine/"+medicineId)
  }

  getPrice(mobile:number,price:number){
    return this.http.get("http://localhost:9989/medicine/getprice/"+mobile+"/"+price)
  }
  setTotalPrice(mobile:number){
    return this.http.get("http://localhost:9989/medicine/setprice/"+mobile);
  }

  updateMedicines(id:number,price:number){
    console.log("in update service"+id);
    console.log("in update service"+price);
   return this.http.put("http://localhost:9989/medicine/updatemedicine/"+id+"/"+price,+id);
  }

  updateDoctors(mobile:number,timming:any,location:any){
    return this.http.put("http://localhost:9989/doctorsdetails/updatedoctors/"+mobile+"/"+timming+"/"+location,+mobile);
  }


  saveProfile(file:File):Observable<any>{
    const formdata=new FormData();
    formdata.append('file',file);
    console.log("hlo");
    return this.http.post("http://localhost:9989/medicine/addMedicines",formdata,{
      reportProgress:true,responseType:'text'
    });
  }

  checkForgotPassword(mobile:number,answer:String){
    console.log("service");
    console.log(mobile);
    console.log(answer);
    return this.http.get("http://localhost:9989/userregistration/getByMobileandanswer/"+mobile+"/"+answer);

  }

  changePassword(mobile:number,pwd:String){
    console.log("service");
    console.log(mobile);
    console.log(pwd);
    return this.http.put("http://localhost:9989/userregistration/updatepassword/"+mobile+"/"+pwd,+mobile);

  }

  addBooking(umobile: String,tmail: String) {
    console.log("adding booking")
    console.log("user mail:"+umobile);
    console.log("technician mail is:"+tmail)
    return this.http.get("http://localhost:9989/userregistration/booking/"+umobile+"/"+tmail);
     
  }
  getBookedUsers(technicianMail: String) {
    console.log("getting booked users")
    console.log("in service booking"+technicianMail);
    return this.http.get("http://localhost:9989/userregistration/getdetails/"+technicianMail);
  
  }

  getDoctorsList(cmobile:number){
    console.log("cmobile"+cmobile);
    return this.http.get("http://localhost:9989/userregistration/bookeddoctors/"+cmobile);

  }
  cancelDoctor(mobile:number,docmail:String){
    console.log("in service cancel"+mobile+docmail);
    return this.http.get("http://localhost:9989/userregistration/cancelbooking/"+mobile+"/"+docmail);
  }
  setStatus(mobile:number,dmobile:any){
    return this.http.get("http://localhost:9989/userregistration/setstatus/"+mobile+"/"+dmobile);
  }
  getStatus(mobile:any,dmobile:any){
    return this.http.get("http://localhost:9989/userregistration/getstatus/"+mobile+"/"+dmobile);
  }

  setMedicinesList(mobile:number,medicineId:String){
    console.log("medicne and number"+mobile+medicineId);
    return this.http.post("http://localhost:9989/userregistration/addMedicinesList/"+mobile+"/"+medicineId,+mobile);
  }

  getMedicinesList(cmobile:any){
    console.log("in service mobile"+cmobile);
    return this.http.get("http://localhost:9989/userregistration/getMedicnesList/"+cmobile);
  }
}
